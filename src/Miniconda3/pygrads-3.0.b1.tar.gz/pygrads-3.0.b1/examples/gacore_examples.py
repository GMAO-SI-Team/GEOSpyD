#!/usr/bin/env python

"""Simple demo of the GrADS class in Python"""

#--------------------------------------------------------------------------
#
#  REVISION HISTORY:
#
#  18Mar2006  da Silva  First crack.
#
#--------------------------------------------------------------------------
#
#    Copyright (C) 2006 by Arlindo da Silva <dasilva@alum.mit.edu>
#    All Rights Reserved.
#
#    This program is free software# you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation# using version 2 of the License.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY# without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program# if not, please consult  
#              
#              http://www.gnu.org/licenses/licenses.html
#
#    or write to the Free Software Foundation, Inc., 59 Temple Place,
#    Suite 330, Boston, MA 02111-1307 USA
#
#------------------------------------------------------------------------

from grads import *
from sys   import stdout

# Start GrADS
# -----------
try:
    ga = GrADS(Verb=1, Echo=False, Port=False, Window=False,
         Opts="-c 'q config'")
    print('>>> OK <<< start GrADS')
except:
    print('>>> NOT OK <<< cannot start GrADS')

# This files does not exist
# -------------------------
try:
    fh = ga.open("wrong_file.nc")  
    print('>>> NOT OK <<< file wrong_file.nc should not exist')
except GrADSError:
    print('>>> OK <<< No such file, we meant that!\n')

# Ok, this one should exist
# -------------------------
print('Opening a CTL file:')
try:
    fh = ga.open("../data/model")
    print(fh)
    print('')
    print(">>> OK <<< open CTL file")
except:
    print(">>> NOT OK <<< cannot open CTL file")

# Ok, sdfopen should work as well
# -------------------------------
print('Opening a NetCDF file:')
try:
    fh = ga.open("../data/model.nc")
    print(fh)
    print(">>> OK <<< open NetCDF file")
except:
    print(">>> NOT OK <<< cannot open NetCDF file")

# Next, check the query method
# ----------------------------
try:
    qh = ga.query('dims')
    print(qh)
    print('')
    print(">>> OK <<< query dimensions")
except:
    print(">>> NOT OK <<< cannot query dimensions")

try:
    qh = ga.query('file')
    print(qh)
    print('')
    print(">>> OK <<< query file")
except:
    print(">>> NOT OK <<< cannot query file")

# Test output capture, 2 modes: line and words
# --------------------------------------------
try:
    ga.cmd("q config")

    print("--------------------------------------------------------------")
    print("            Captured GrADS output: Line interface")
    print("--------------------------------------------------------------")
    for i in range(1,ga.nLines):
        print(ga.rline(i))
    print("                          ---------")

    print("")
    print("--------------------------------------------------------------")
    print("            Captured GrADS output: Word interface")
    print("--------------------------------------------------------------")
    for i in range(1,ga.nLines):
        for j in range(1,20):     # 20 is an over estimate, but i is OK
            stdout.write(ga.rword(i,j)+' ')
        stdout.write('\n')
    print("                          ---------")
    print("")
    print(">>> OK <<< rline()/rword() completes")
except:
    print(">>> NOT OK <<< rline()/rword() fails")

# Testing the eval function
# -------------------------
try:
    ts = ga.eval('ts')
    print('ts  min/max:', min(ts), max(ts))

    print("")
    print(">>> OK <<< eval completes")
except:
    print(">>> NOT OK <<< eval fails")


    
# Entering a bunch of comands at once
# -----------------------------------
print("")
print("--------------------------------------------------------------")
print("         Entering a Bunch of commands at once")   
print("--------------------------------------------------------------")
try:
    ga("""
           set lat 30 60
           set lon -80 -50
           set t 1 3
           query dims
       """)
    print(">>> OK <<< successfuly ran several commands at one")
except:
    print(">>> NOT OK <<< could not run several commands at once")

print("All done.")
