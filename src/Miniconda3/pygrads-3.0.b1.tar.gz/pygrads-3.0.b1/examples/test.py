from grads import GrADS
from grads import gacm
from matplotlib.pylab import *

from PIL               import Image

import numpy as np

if __name__ == "__main__":

    ga = GrADS(Window=False,Echo=True)
#    ga('@ open $GADSET/model')
    ga('sdfopen ../data/aero.nc')
    
    #ga.blue_marble('on')    # use Blue Marble background
    ga.basemap('latlon')
    ga.imshow('duexttau',cmap=gacm.hot_l)
    title("Mineral Dust Optical Thickness")
    show()

def zzz():

    ts = ga.exp('ts') - 273.0
    ga.imshow(ts)
    show()
    
    ga('sdfopen ../data/aero.nc')

    #ga.basemap('geos',opts=-75.) # GOES East
    #ga.blue_marble(Show=True)
    #title("Geostationary Projection (GOES East)")

    #ga.basemap('npo') 
    #ga.blue_marble(Show=True)
    #title("Orthographic Projection (North Pole)")

    #sat = Image.open("goes_fulldisk.jpg")
    #ga.basemap('geos',opts=-75.) # GOES East
    #ga.imshow('duexttau',  cmap=gacm.hot_l,bgim=sat,
    #               mpcol='cyan',dlon=20,dlat=15)
    #title("Mineral Dust Optical Thickness")
        

    ga.blue_marble('on')    # use Blue Marble background
    ga.basemap('latlon')
    ga.imshow('duexttau',cmap=gacm.hot_l)
    title("Mineral Dust Optical Thickness") 
    #ga.blue_marble('off')  

    
def imp():
    
    ga('set t 1')
    ga('set z 1')
    ts = ga.exp('ts') - 273.0
    print("starting with 2d slice import...")
    ga.imp('ts1',ts)

    print("done with 2d slice")
            
    ga('set t 1 5')
    ts = ga.exp('ts')  - 273.0
    ga.imp('ts2',ts)

    print("done with 3d slice")

    ga('set z 1 7')
    ua = ga.exp('ua') 
    ga.imp('ts3',ua)

    print("done with 4d slice")

    ga('set t 3')
    ga('set z 4')
    ga.imp('ts3',ua)

    print("done with importing 2d slice from 4d data")


def export():
    
    ga('set t 1')
    ga('set z 1')
    ts = ga.exp('ts')
    print("done with 2d slice")
        
    ga('set t 1 5')
    ts = ga.exp('ts')
    print("done with time + 2d slice")

    ga('set z 1 7')
    ua = ga.exp('ua')
    print("done with 4D slice")
    

def hold():

    one = np.ones((10,10))
    five = 5. * np.ones((10,10))

    mask = np.zeros((10,10)).astype('bool')
    mask[2:4] = True

    gaOne = GaField(one,name='GrADS One')
    gaFive = GaField(five,mask=mask,name='GrADS Five')
    
#    gaFive = GaField(five,mask,'GrADS Five')

    gaSix = gaOne + gaFive
    

    

